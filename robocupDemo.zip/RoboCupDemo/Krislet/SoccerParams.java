//
//	File:			SoccerParams.java
//	Author:		Krzysztof Langner
//	Date:			1997/04/28
//

class SoccerParams 
{
	final static int	simulator_step = 100;
}

